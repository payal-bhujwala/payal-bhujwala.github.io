<h3>Light Modal</h3>
<a href="https://hunzaboy.github.io/Light-Modal/">View the Awesome Demo</a>

<p>A simple light-weight yet <strong>Powerful</strong> and <strong>Customizable</strong> <code>css</code> modal for content and images.</p>
<p><a href="https://hunzaboy.github.io/Light-Modal/"><img src="screen-2.png" alt="screenshot"><img src="screen.png" alt="screenshot"> </a>
<hr />
<a href="https://hunzaboy.github.io/Light-Modal/"> Click here for a DEMO &
 How to use</a>
 
 <h3>Compatibility </h3>
 IE9+, Safari, Chrome, Firefox 
 
 <em>Light Modal uses Flex and Target CSS properties.</em>


<h3>To Do </h3>
<em>Fell free to submit a PR </em>

- [ ] JS Version
- [ ] IE9 and/or below

<h3>Changelog</h3>
v 1.1.0 - Added new Gallery Mode
<hr>

<a href='https://ko-fi.com/W7W112WHD' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi2.png?v=2' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>
