// Yeah, no javascript :) 

  function testAnim(x) {
    $('.modal-content').removeClass().addClass(x + ' modal-content animated');
  };

  $(document).ready(function(){
    $('.js--triggerAnimation').click(function(e){
      e.preventDefault();
      var anim = $('.js--animations').val();
      testAnim(anim);
    });

    $('.js--animations').change(function(){
      var anim = $(this).val();
      testAnim(anim);
    });
  });

