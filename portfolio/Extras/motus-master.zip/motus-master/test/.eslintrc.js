module.exports = {
  env: {
    eslint: true,
  },
  plugins: ['jest'],
  globals: {
    expect: true,
  },
};
