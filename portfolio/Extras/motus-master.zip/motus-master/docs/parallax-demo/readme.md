# [Medium article](https://medium.com/@alexcambose/creating-a-parallax-effect-with-motus-af89bdc3ce1a)
