export const isSet = value => value === 0 ? true : !!value;
