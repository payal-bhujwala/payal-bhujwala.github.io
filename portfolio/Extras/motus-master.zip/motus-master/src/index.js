import Motus from './Motus';

if (typeof window !== 'undefined') {
  window.Motus = Motus;
}
export default Motus;
