module.exports = {
    collectCoverageFrom: [
        "src/**/*",
        "!<rootDir>/node_modules/",
        "!<rootDir>/dist"
    ],
};
